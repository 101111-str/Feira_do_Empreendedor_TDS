---
name: Entregável
about: Um item de escopo com critério de aceite verificável
title: '[Fx] '
labels: entregavel
---

## Frente
<!-- F1 Plataforma | F2 Conteúdo | F3 Infra de Campo | F4 Operação & Palco | F5 Qualidade -->

## Responsável
<!-- Nome do aluno. Toda tarefa tem dono nomeado. -->

## O que é

## Critério de aceite
<!-- Verificável e objetivo. "Funciona bem" não é critério. -->
- [ ]

## Prazo
<!-- Semana de referência: S-10 a S-0 -->

## Dependências
<!-- De quem este item depende para começar ou terminar -->
