---
name: Incidente
about: Algo quebrou durante ensaio ou durante o evento
title: '[INCIDENTE] '
labels: incidente
---

## Quando
<!-- Data e horário -->

## Onde
<!-- Posto, espaço ou sistema -->

## O que aconteceu

## O que foi feito

## Duração do impacto
<!-- Minutos em modo degradado, se aplicável -->

## Causa raiz
<!-- Preencher no pós-morte, não durante o incidente -->

## Ação preventiva
