# Cronograma — Operação TDS

Contagem regressiva até o dia do evento. **Nos gates, critério não atingido não empurra prazo — reduz escopo.**

| Semana | Marco | F1 Plataforma | F2 Conteúdo | F3 Infra | F4 Palco | F5 Qualidade |
|---|---|---|---|---|---|---|
| `S-10` | Fundação | — | — | Levantamento do local · Inventário | — | — |
| `S-9` | Kickoff | Stack + esqueleto | Inventário de conteúdo | Plano da frente | Plano da frente | Plano da frente |
| `S-8` | — | Hotsite navegável | Estrutura fechada · fichas iniciadas | Mapa de energia validado | Cronograma do palco | — |
| `S-7` | — | Check-in em laboratório | Metade das fichas | Lista de aquisição | — | Roteiros de teste |
| `S-6` | **🚩 GATE 1** | Integração ponta a ponta | Textos do hotsite | Teste de rede no local | — | Valida o gate |
| `S-5` | — | Catálogo · EcoTracker · Pesquisa | Conteúdo completo · divulgação | Equipamentos testados | Plano de som · escala rascunho | — |
| `S-4` | **🚩 GATE 2** | **Feature freeze** | Início da impressão | — | — | — |
| `S-3` | Ensaio 1 | Correções | Produção de QR | Rede no local · queda proposital | Trilha testada | **Conduz o ensaio** |
| `S-2` | **🚩 GATE 3** | Correções aplicadas | QR conferidos e plastificados | — | **Escala publicada** | **Parecer go/no-go** |
| `S-1` | Congelamento | — | — | Dispositivos preparados · kit | Briefing final | **Ensaio 2** |
| `S-0` | Evento | Suporte | — | Montagem · desmontagem | Operação | Plantão · registro |

---

## Critérios dos gates

### 🚩 `S-6` · GATE 1 — Integração
Hotsite no ar com conteúdo real, e check-in + painel funcionando ponta a ponta com dados de teste, **fora da máquina de quem programou**. Primeiro teste de rede no local.

**Se falhar:** catálogo da galeria e pesquisa saem do escopo de F1 e viram material impresso.

### 🚩 `S-4` · GATE 2 — Feature freeze
Todos os seis entregáveis digitais existem e funcionam. A partir daqui, F1 **só corrige defeito** — nada novo entra, nem "é rapidinho".

### 🚩 `S-2` · GATE 3 — Go / No-go
Ensaio de `S-3` aprovado com correções aplicadas. Cada entregável recebe go ou no-go **individual** — não é tudo ou nada.

**Se um item receber no-go:** sai da operação e vira demonstração no estande do TDS.

---

## Ritmo semanal fixo

| Quando | O quê | Duração | Quem |
|---|---|---|---|
| 2× por semana | Check-in de líderes | 20 min | Gestor + 5 líderes |
| Semanal | Um-a-um | 15 min | Gestor + cada líder |
| Sexta | Demo geral — software rodando | 40 min | Toda a equipe |
| Quinzenal | Revisão de riscos | 30 min | Gestor + 5 líderes |
