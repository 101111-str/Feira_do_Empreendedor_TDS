# Parecer Técnico — Proposta TechFerry

Análise crítica da proposta de T.I. contra o plano geral da III Feira de Trocas e Empreendedorismo, CETI João Ferry, Agricolândia (PI).

> Este parecer é o documento que originou o [plano de execução](README.md). Ele é mantido no repositório porque **justifica as decisões** do plano — em especial a retirada do sistema financeiro do escopo do TDS.

**Documentos analisados**

| ID | Documento | Conteúdo |
|---|---|---|
| `DOC-01` | Mercado João Ferry 2026 · 11 slides | Projeto geral da feira |
| `DOC-02` | Projeto TechFerry 2026 · 10 slides | Proposta de T.I. |

---

## Veredito

O TechFerry acerta o diagnóstico: o papel do TDS no `DOC-01` é decorativo — "emissão de QR Codes" e "aparato tecnológico de divulgação" é suporte, não protagonismo. A ambição de transformar o curso no operador da infraestrutura do evento é correta e defensável.

**O que o `DOC-02` não é:** um plano de engenharia. Não há headcount, stack, MVP, critério de aceite, estimativa, ambiente de homologação, nem tratamento de dados. Há três cartões — *Back-end / Front-end / Infra* — e uma promessa de "tolerância zero-delay", que é slogan, não requisito verificável.

**Dois defeitos estruturais bloqueavam a aprovação como estava:** a proposta colocava software ainda não escrito no caminho crítico da economia do evento, substituindo um sistema físico que já funciona; e estava fora de fase com o cronograma do próprio projeto geral.

---

## Inconsistência bloqueante entre os documentos

Apresentados no mesmo pacote, `DOC-01` e `DOC-02` fazem afirmações que não podem ser verdadeiras ao mesmo tempo sobre o mesmo sistema:

> **`DOC-01` · Prontidão Operacional**
> ✅ Sistemas de TI e QR Codes testados. ✅ Moeda Social impressa.
> O planejamento metodológico, logístico e de equipes está 100% finalizado.

> **`DOC-02` · O Gap Tecnológico**
> QR Codes Básicos: emissão estática sem sistema de validação.
> Formulários: cadastro manual de visitantes. Atuação limitada.

Ou o checklist foi marcado sem verificação — e aí os outros três itens também estão sob suspeita —, ou o TechFerry é proposta para a edição seguinte. O `DOC-01` posiciona o projeto em **Montagem**, a penúltima etapa, enquanto o `DOC-02` fala em "ciclos iterativos semanais até o evento", ou seja, desenvolvimento ainda não começado.

**Ação:** resolver antes de alocar qualquer pessoa. E não levar os dois arquivos juntos à direção sem reconciliar: quem ler "100% finalizado" num e "gap tecnológico" no outro vai desconfiar dos dois.

---

## Matriz de riscos original

Severidade medida por impacto no evento, não por dificuldade técnica. **Crítico = o evento não roda.**

| ID | Severidade | Risco | Estado após a decisão de escopo |
|---|---|---|---|
| `R-01` | Crítico | Software inédito no caminho crítico da moeda | **Eliminado** |
| `R-02` | Crítico | Infraestrutura de campo não especificada | Permanece → `A-02` |
| `R-03` | Alto | Adoção pelo público será baixa | Resolvido por desenho |
| `R-04` | Alto | Integridade do valor — isto é uma moeda | **Eliminado** |
| `R-05` | Alto | LGPD e dados de menores | Reduzido → `B-07` |
| `R-06` | Alto | Conflito de governança com Administração | **Eliminado** |
| `R-07` | Alto | Gestor acumulando execução — fator ônibus 1 | Permanece → mandato |
| `R-08` | Médio | Passaporte duplicado | Resolvido → `M-05` |
| `R-09` | Médio | Escopo sem dimensionamento | Resolvido pelo plano |
| `R-10` | Médio | Expectativa criada pelos mockups | Permanece |

### `R-01` · Crítico · Software inédito no caminho crítico da moeda

Se o FerryPay for o meio de troca, qualquer falha — queda de rede, bateria, bug de saldo, servidor fora — congela a economia inteira: sem câmbio no Banco, sem venda nos estandes, sem Desafio Jovem Empreendedor. A moeda impressa já existe, funciona offline, não tem dependência de energia e tem custo marginal zero. Trocá-la por software que ainda não foi escrito é **regressão de confiabilidade vendida como inovação**.

**Mitigação adotada:** a moeda física permanece o instrumento oficial de liquidação. O digital vira camada de registro e auditoria sobre ela — tecnicamente mais interessante e sem risco sistêmico.

### `R-02` · Crítico · Infraestrutura de campo não especificada

O evento acontece em via asfaltada interditada — ambiente externo. O `DOC-02` não declara topologia de rede, quantidade e posição de pontos de acesso, fonte de energia e autonomia, número de dispositivos concorrentes, nem cobertura no zoneamento. **"Servidor local assegurando tolerância zero-delay" não é um requisito:** não há como testá-lo nem como reprová-lo.

**Mitigação adotada:** alvo mensurável, ex.: *confirmação de transação abaixo de 2s no percentil 95 com 40 dispositivos ativos; entrada em modo offline em menos de 5s após perda de link*.

### `R-03` · Alto · Adoção pelo público será baixa

O modelo implícito é o visitante instalar um PWA no próprio celular, numa rede local sem internet, em público comunitário heterogêneo. A taxa de instalação será baixa e o atrito de acesso vira fila no ponto único de controle.

**Mitigação adotada:** o software roda no dispositivo do **aluno operador**, nunca no do visitante. O visitante carrega apenas um passaporte impresso com QR.

### `R-04` · Alto · Integridade do valor

Ataques triviais num contexto escolar: operador credita saldo na própria conta; QR de pagamento reapresentado duas vezes (*replay*); alteração direta de saldo no banco de dados.

**Requisitos que seriam mínimos:** ledger *append-only* — transação é fato imutável, saldo é sempre derivado, nunca campo editável; token de transação de uso único com expiração curta; contas de operador segregadas; log de auditoria imutável; conferência de fechamento por turno.

### `R-05` · Alto · LGPD e dados de menores

"Rastreabilidade: coleta massiva de dados do evento" + check-in de visitantes + cadastro digital. Participantes e público incluem menores de idade. Sem base legal, consentimento, minimização e prazo de descarte, quem assume o risco jurídico é a escola.

**Mitigação adotada:** nenhum dado pessoal direto; identificador pseudônimo impresso; métricas agregadas; descarte 30 dias após o relatório final.

### `R-06` · Alto · Conflito de governança com Administração

O `DOC-01` atribui ao curso de Administração a gestão do Banco, auditoria, controle de caixa e prestação de contas. O `DOC-02` entrega ao TDS a "custódia segura da Moeda Social" e um "painel de auditoria — dashboard centralizado do banco". **São a mesma responsabilidade, atribuída duas vezes.**

**Mitigação adotada:** retirada integral do escopo financeiro do TDS.

### `R-07` · Alto · Gestor acumulando execução

Gestão de equipe, logística e projetos próprios em paralelo, mais papel técnico no dia do evento, não cabem na mesma pessoa. Se o gestor for a única pessoa que sabe subir o servidor ou gerar os QR, ele não estará disponível para o papel que de fato exerce.

**Mitigação adotada:** mandato formal, cinco líderes de frente, fator ônibus mínimo 2 em todo procedimento crítico.

### `R-08` · Médio · Passaporte duplicado

O `DOC-01` já define o Passaporte do Leitor físico, com selos em quatro espaços — Banco, Arte, Escambo, Verde. O "Passaporte Integrado" do `DOC-02` reimplementa o mesmo conceito em digital.

**Mitigação adotada:** um só passaporte. Físico primário com carimbo; QR no mesmo cartão espelhando o registro digital.

### `R-09` · Médio · Escopo sem dimensionamento

Dois produtos, um backend, um PWA e infraestrutura de campo, executados por alunos em paralelo às aulas, sem headcount, stack, MVP, critério de aceite ou estimativa. Um deck de proposta pode ser aspiracional; uma alocação de equipe não pode.

### `R-10` · Médio · Expectativa criada pelos mockups

As telas do FerryPay no `DOC-02` são imagens de banco — o próprio slide final credita `dribbble.com` e `istockphoto.com`. Legítimo num pitch, perigoso numa apresentação à direção: se o gestor memorizar aquela tela e receber um formulário funcional simples, a equipe entrega corretamente e é lida como tendo falhado.

**Mitigação:** rotular as imagens como "referência visual", ou substituir por captura do protótipo real.

---

## Modelo de contrato de interface TDS ↔ Administração

Mantido aqui para referência. Com o escopo financeiro retirado, a maior parte deixa de ser necessária — mas o modelo continua válido caso o FerryPay seja retomado na edição 2027.

| Item | TDS responde por | Administração responde por |
|---|---|---|
| Saldo e moeda | Integridade técnica do registro; nenhum saldo editável fora de transação | Valor emitido, lastro, custódia física |
| Fechamento de turno | Gerar o extrato conferível a partir do ledger | Conferir, divergir e assinar |
| Divergência de caixa | Fornecer o log de auditoria da janela | Decidir o ajuste e registrar a justificativa |
| Indisponibilidade | Declarar a queda e acionar a degradação | Operar em papel e conciliar depois |
| Dados do evento | Coletar apenas pseudônimos; descartar no prazo | Aprovar quais métricas serão publicadas |

---

*Parecer elaborado sobre os dois documentos fornecidos, sem acesso a cronograma absoluto, orçamento ou composição da equipe no momento da análise.*
