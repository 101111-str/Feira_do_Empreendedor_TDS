# Operação TDS — Mercado João Ferry 2026

Plano de produção e execução da equipe do curso técnico em **Desenvolvimento de Sistemas (TDS)** na III Feira de Trocas e Empreendedorismo — CETI João Ferry, Agricolândia (PI).

| | |
|---|---|
| **Gestor geral** | Weslley Kelven |
| **Janela** | 10 semanas · `S-10` → `S-0` |
| **Equipe** | 20+ alunos · 5 frentes |
| **Fora de escopo** | Sistema financeiro (moeda digital) |

> Versão navegável do plano: [`docs/index.html`](docs/index.html) · Análise crítica que originou este plano: [`PARECER.md`](PARECER.md)

---

## Índice

1. [Decisão estruturante: retirada do sistema financeiro](#1-decisão-estruturante-retirada-do-sistema-financeiro)
2. [Contexto consolidado do projeto geral](#2-contexto-consolidado-do-projeto-geral)
3. [Escopo do TDS](#3-escopo-do-tds)
4. [Fora de escopo](#4-fora-de-escopo--declarado)
5. [Mandato do gestor geral](#5-mandato-do-gestor-geral)
6. [Estrutura de equipe: cinco frentes](#6-estrutura-de-equipe-cinco-frentes)
7. [Análise de capacidade](#7-análise-de-capacidade-o-gargalo-não-é-mão-de-obra)
8. [Cronograma: dez semanas, três gates](#8-cronograma-dez-semanas-três-gates)
9. [Runbook do dia do evento](#9-runbook-do-dia-do-evento)
10. [Métricas de sucesso](#10-métricas-de-sucesso)
11. [Matriz de riscos](#11-matriz-de-riscos)
12. [Próximos sete dias](#12-próximos-sete-dias)

---

## 1. Decisão estruturante: retirada do sistema financeiro

Retirar a moeda digital do escopo do TDS resolve sozinha os três riscos críticos identificados na análise inicial:

- o software sai do **caminho crítico** da economia do evento;
- desaparece a **superfície de fraude** de um sistema de valor operado por alunos;
- some o **conflito de responsabilidade** com o curso de Administração, que volta a ser dono exclusivo do Banco da Feira, da moeda impressa e da prestação de contas.

**O custo dessa decisão é retórico, não técnico.** O argumento de protagonismo da proposta TechFerry se apoiava em "ser a infraestrutura financeira do evento". Esse argumento é substituído, não abandonado: o TDS passa a ser dono da **experiência digital do visitante** e da **operação técnica da feira inteira** — som, energia, rede, registro, painel ao vivo. É mais visível ao público, mais defensável academicamente, e não derruba o evento se falhar.

Com isso, **nenhum entregável do TDS é bloqueante para a feira acontecer.** É essa propriedade que torna o plano viável em dez semanas com uma turma majoritariamente iniciante.

### Reclassificação dos riscos originais

| Risco original | Estado | Justificativa |
|---|---|---|
| R-01 · Software no caminho crítico | **Eliminado** | Sem moeda digital, a economia do evento roda em papel de ponta a ponta |
| R-04 · Integridade do valor | **Eliminado** | Não há saldo, ledger nem transação financeira |
| R-06 · Conflito com Administração | **Eliminado** | Auditoria e caixa permanecem integralmente com Administração |
| R-05 · LGPD | **Reduzido** | Sem cadastro de visitante; só contagem por código impresso anônimo |
| R-02 · Infra de campo | **Permanece** | Energia e rede em via asfaltada seguem sendo a maior ameaça |
| — · Gargalo de revisão | **Novo** | 20+ alunos com 2–3 avançados: o limite é revisar, não produzir |

### Destino da proposta TechFerry

A proposta não é descartada — é reposicionada. O FerryPay vira **projeto declarado da edição 2027**, com protótipo navegável demonstrado no estande do próprio TDS durante esta feira. A equipe apresenta o que construiu e o que pretende construir, sem colocar a economia do evento em risco para provar o ponto.

> ⚠️ Antes de qualquer apresentação oficial, troque os mockups de banco de imagens do deck original (dribbble, istockphoto) por capturas do protótipo real, ou rotule-os explicitamente como referência visual.

---

## 2. Contexto consolidado do projeto geral

Síntese dos dois documentos originais, para quem precisar operar o plano sem ter lido os decks.

- **Evento:** Mercado João Ferry — III Feira de Trocas e Empreendedorismo, edição 2026. Via asfaltada interditada, ponto único de entrada e saída monitorado, zoneamento entre praça de alimentação, palco cultural e estandes principais. Estandes modulares de madeira substituindo barracas de lona.
- **Pilares:** protagonismo juvenil, economia circular e educação financeira, alinhados à Agenda 2030.
- **Banco da Feira:** arrecadação na comunidade → triagem técnica → câmbio em moeda social → consumo em economia fechada. Alunos operam como gerente, avaliadores, controladores financeiros e auditores. *Curso responsável: Administração.*
- **Espaços:** Escambo Literário com cafeteria imersiva (livros misteriosos, árvore dos desejos, lambe-lambe), Galeria de Arte Estudantil com obras identificadas e precificadas e visitas guiadas, Palco Cultural com cronograma ininterrupto, Desfile da Sustentabilidade, Feira Verde com oficinas de horta e compostagem.
- **Mecânicas de engajamento:** Passaporte do Leitor para o público, com selos nos quatro espaços — Banco, Arte, Escambo, Verde — e Desafio Jovem Empreendedor para os alunos.
- **Papel original do TDS:** emissão de QR Codes, cadastro digital e aparato tecnológico de divulgação — escopo de apoio, que este plano substitui.

### ⚠️ Pendência herdada — resolver antes do gate `S-10`

O projeto geral marca **"Sistemas de TI e QR Codes testados"** como concluído, enquanto a proposta de T.I. descreve os QR Codes atuais como **"emissão estática sem sistema de validação"**. As duas afirmações não podem ser verdadeiras ao mesmo tempo.

Este plano assume a segunda e produz os QR do zero. Se a primeira for verdadeira, a frente F2 ganha aproximadamente duas semanas.

---

## 3. Escopo do TDS

O TDS opera em duas naturezas de trabalho diferentes. É essa separação que permite absorver uma turma grande e desnivelada: o braço de produto consome poucos alunos avançados, o braço de operação consome muitos alunos iniciantes em trabalho de alto valor e baixo risco técnico.

### Braço A — Produto digital

| Entregável | O que é | Critério de aceite |
|---|---|---|
| **Hotsite do evento** | Página pública com programação, mapa do zoneamento, espaços, expositores e como participar. Funciona antes, durante e depois. | No ar em `S-6`, com conteúdo real, legível no celular e sem dependência da rede local |
| **Passaporte do Visitante** | Espelho digital do passaporte físico. O aluno operador escaneia o QR do cartão em cada um dos quatro espaços. O visitante não instala nada. | Check-in em menos de 5s; funciona offline com fila local; degrada para carimbo sem perder registro |
| **Painel ao Vivo** | Tela no evento e página pública: visitantes por espaço, fluxo por hora, próximo item do Palco Cultural, contador do EcoTracker. | Atualiza a cada 60s; legível a 3 metros; não trava se um posto cair |
| **Catálogo da Galeria** | QR por obra levando à ficha do artista, título, técnica e preço. Substitui a etiqueta de papel e viabiliza a visita guiada. | 100% das obras com ficha publicada e QR impresso até `S-2` |
| **EcoTracker** | Registro de itens e quilos desviados do descarte na triagem e no escambo. Produz o número que comprova o pilar de economia circular. | Operável por aluno da triagem em menos de 20s; total exibido no Painel ao Vivo |
| **Pesquisa de satisfação** | QR na saída, questionário curto. Instrumento fornecido pelo TDS, processo e leitura pela Administração. | No ar em `S-2`; máximo 6 perguntas; resultado exportável |

### Braço B — Operação técnica do evento

| Entregável | O que é | Critério de aceite |
|---|---|---|
| **Sonorização e trilha** | Som do Palco Cultural, microfone do mestre de cerimônia, trilha da Cafeteria Literária, apoio ao Desfile. | Cronograma do palco cumprido sem interrupção técnica; operador e reserva escalados por turno |
| **Energia e cabeamento** | Mapa de tomadas, extensões, proteção, carga de dispositivos, pontos de energia por zona. | Mapa validado no local em `S-8`; autonomia de todos os postos coberta por powerbank |
| **Rede local** | Cobertura nos postos de check-in e no Painel ao Vivo. Projetada para funcionar mal — todo posto opera offline por padrão. | Testada no local em `S-6` e no ensaio de `S-3`, com teste de queda proposital |
| **Produção de QR e sinalização** | Geração, impressão, plastificação e fixação: passaportes, obras, espaços, pesquisa, percurso. | Impressos, conferidos e plastificados até `S-2`; amostra testada sob sol direto |
| **Registro audiovisual** | Fotografia, vídeo e cobertura para redes durante o evento; material de divulgação antes. | Pauta de captura definida em `S-3`; material editado até 7 dias após o evento |
| **Plantão técnico** | Suporte em campo durante toda a feira, com titular e reserva por turno, e degradação ensaiada. | Escala publicada em `S-2`; nenhum incidente que pare a programação do palco |

---

## 4. Fora de escopo — declarado

- **Carteira digital, saldo, transferência e câmbio.** A moeda social permanece integralmente física e sob a Administração.
- **Painel de auditoria financeira e custódia de valor.** Conciliação de caixa é processo de Administração, em papel.
- **Cadastro nominal de visitantes.** Apenas código impresso anônimo, sem nome, telefone, CPF ou foto, com descarte 30 dias após o relatório final.
- **Aplicativo instalável pelo público.** Nada roda no celular do visitante; tudo roda no dispositivo do aluno operador.

---

## 5. Mandato do gestor geral

Com mais de 20 alunos, a armadilha previsível é coordenar todo mundo diretamente e virar o gargalo de tudo. O alcance de comando é **cinco pessoas**: os líderes de frente.

| Dimensão | O gestor decide e responde | O gestor não faz |
|---|---|---|
| **Escopo** | O que entra, o que sai, o que é cortado em cada gate | Implementar o que foi decidido |
| **Pessoas** | Alocação entre frentes; nomeação e substituição de líderes | Distribuir tarefa individual — isso é do líder de frente |
| **Prazo** | Declarar atraso, acionar corte, decidir go/no-go em `S-2` | Absorver atraso trabalhando no lugar da equipe |
| **Interfaces** | Direção, Administração, Agropecuária, Grêmio e fornecedores | Negociar detalhe operacional que o líder resolve sozinho |
| **Dia do evento** | Circular, desbloquear, autorizar degradação, falar com a direção | Assumir posto de check-in, mesa de som ou terminal |

### Formalize antes de começar

Uma página assinada pela coordenação do curso definindo que o gestor decide escopo e realoca pessoas dentro do TDS. **Responsabilidade sem autoridade é a forma mais comum de um gestor de projeto escolar falhar:** ser cobrado pelo resultado e precisar de licença para cada decisão que o produziria.

### Ritmo de gestão

- **Check-in de líderes, 2× por semana, 20 minutos.** Pauta fixa: o que travou, o que muda de prazo, o que preciso decidir.
- **Um-a-um de 15 minutos com cada líder, semanal.** É onde aparece o problema que ninguém fala na reunião coletiva.
- **Demo geral toda sexta, 40 minutos.** Software rodando e material físico na mesa, não slide. Toda a equipe assiste.
- **Revisão de riscos quinzenal** sobre a matriz da seção 11, com os cinco líderes.
- **Quadro único visível** para as cinco frentes, com limite de **uma tarefa em andamento por aluno**.

---

## 6. Estrutura de equipe: cinco frentes

| Frente | Tamanho | Escopo | Perfil do líder | Risco |
|---|---|---|---|---|
| [**F1 · Plataforma**](frentes/F1-plataforma.md) | 5–6 | Único time que escreve código de produto | Aluno mais experiente | Alto |
| [**F2 · Conteúdo & Identidade Digital**](frentes/F2-conteudo.md) | 5–6 | Todo o conteúdo que o produto exibe + produção de QR | Comunicação e organização | Alto |
| [**F3 · Infra de Campo**](frentes/F3-infra-campo.md) | 4–5 | Rede, energia, dispositivos, montagem | Segundo mais experiente | Alto |
| [**F4 · Operação & Palco**](frentes/F4-operacao-palco.md) | 4–5 | Som, trilha, cronograma do palco, escala de postos | Coordenação, não técnico | Médio |
| [**F5 · Qualidade, Registro & Plantão**](frentes/F5-qualidade-registro.md) | 3–4 | Testes, ensaios, plantão, registro audiovisual | Terceiro mais experiente | — |

### Por que F5 não fica dentro de F1

Quem escreve o código não pode ser quem decide se o código está pronto. Com prazo apertado, a pressão para aprovar a própria entrega é grande demais. **F5 reporta direto ao gestor** — é a única fonte independente sobre o estado real do projeto, e a única confiável na semana do go/no-go.

---

## 7. Análise de capacidade: o gargalo não é mão de obra

Com 20+ alunos e apenas 2–3 avançados, a intuição é distribuir gente por todas as frentes técnicas. É o erro clássico: acrescentar iniciantes a uma frente de código **reduz** a velocidade dela, porque cada linha escrita por um iniciante consome tempo de revisão de um avançado — e revisão é exatamente o recurso escasso.

**Regra operacional:**

> No máximo **seis alunos** tocam o código do produto. Os outros quinze trabalham em conteúdo, produção física, campo, operação e teste — trabalho indispensável, avaliável, e que escala com gente.

Isso também resolve o problema silencioso de projeto escolar com turma grande: aluno sem tarefa nomeada evapora em duas semanas e volta só no dia do evento sem saber o que fazer. **Cada um dos 20+ precisa ter o nome escrito em uma tarefa no quadro desde a primeira semana.**

---

## 8. Cronograma: dez semanas, três gates

Semanas em contagem regressiva até o dia do evento. Nos gates, o critério não atingido **não empurra prazo — reduz escopo**.

### `S-10` — Fundação
Semana de gestão pura. Nada de código.
- Mandato assinado com a coordenação e organograma definido
- Cinco líderes nomeados e briefados individualmente
- Primeira visita de levantamento ao local: energia, rede, zoneamento
- Inventário de dispositivos, computadores e equipamento de som
- Confirmação da pendência de QR herdada do projeto geral

### `S-9` — Kickoff e planos de frente
- Reunião geral com toda a equipe: escopo, frentes, quadro, regras
- Cada líder entrega o plano de uma página da sua frente, com nomes por tarefa
- F1 fixa a stack e sobe o esqueleto do hotsite
- F2 inicia o inventário de conteúdo: obras, espaços, programação do palco

### `S-8` — Primeiras entregas reais
- **F1:** hotsite navegável com conteúdo parcial verdadeiro
- **F2:** estrutura de conteúdo fechada; coleta das fichas de obra iniciada
- **F3:** mapa de energia e cabeamento validado no local
- **F4:** cronograma preliminar do Palco Cultural alinhado com o Grêmio

### `S-7` — Núcleo funcional
- **F1:** check-in do passaporte funcionando em laboratório
- **F2:** metade das fichas de obra escritas e revisadas
- **F3:** lista de equipamentos a comprar ou pedir emprestado fechada
- **F5:** roteiros de teste escritos, antes de existir o que testar

### 🚩 `S-6` — GATE 1 · Integração
**Critério:** hotsite no ar com conteúdo real, e check-in + painel funcionando ponta a ponta com dados de teste, **fora da máquina de quem programou**. Primeiro teste de rede no local.

**Se falhar:** catálogo da galeria e pesquisa saem do escopo de F1 e viram material impresso.

### `S-5` — Completar e revisar
- **F1:** catálogo da galeria e EcoTracker
- **F2:** conteúdo completo em revisão final; material de divulgação no ar
- **F3:** equipamentos confirmados e testados em bancada
- **F4:** escala do dia do evento em rascunho

### 🚩 `S-4` — GATE 2 · Feature freeze
**Critério:** todos os seis entregáveis digitais existem e funcionam. A partir daqui, F1 **só corrige defeito** — nada novo entra, nem "é rapidinho".

Início da produção física: impressão e plastificação de QR, passaportes e sinalização.

### `S-3` — Ensaio geral 1, no local
- Rede, energia e dispositivos reais montados no espaço do evento
- Três postos operando, 50 check-ins cronometrados
- **Teste de degradação:** derrubar a rede e medir o retorno ao carimbo
- F5 registra defeitos e tempos; F1 corrige na semana seguinte
- Pauta de captura audiovisual definida

### 🚩 `S-2` — GATE 3 · Go / No-go
**Critério:** ensaio de `S-3` aprovado com correções aplicadas. Cada entregável recebe go ou no-go **individual** — não é tudo ou nada.

**Se um item receber no-go:** sai da operação e vira demonstração no estande do TDS. QR impressos e conferidos, escala do dia publicada, pesquisa de satisfação no ar.

### `S-1` — Ensaio geral 2 e congelamento total
- Jornada completa ensaiada: entrada → Banco → estandes → escambo → galeria → saída
- Kit de contingência montado e conferido item a item
- Dispositivos carregados, etiquetados e separados por posto
- Briefing final: cada aluno sabe seu posto, turno e substituto

### `S-0` — Montagem e evento
- **Véspera:** montagem, teste ponta a ponta no local, carga total de dispositivos
- **Dia:** operação conforme runbook
- **Depois:** desmontagem, recolhimento e conferência de equipamento

---

## 9. Runbook do dia do evento

- **O gestor circula, não opera.** Sem posto fixo, sem mesa de som, sem terminal.
- **Plantão técnico com titular e reserva por turno**, nomeados na escala de `S-2`, com contato que funcione no volume do palco.
- **Todo posto tem substituto escalado.** Aluno que precisa sair não deixa um espaço do passaporte sem operador.
- **Degradação autorizada por uma única pessoa** — o gestor ou o líder de F5. Procedimento: parar o registro digital, passar ao carimbo, anotar o horário. Reconciliação depois, nunca durante.
- **Kit de contingência ao alcance:** passaportes em branco, carimbos, powerbanks carregados, roteador reserva, extensões, cabos, fita, etiquetas, canetas, lista impressa de contatos.
- **Registro de incidentes em papel**, preenchido durante a feira por F5. Vira o pós-morte e o material de avaliação.
- **Fechamento por turno**, não só no fim: cada líder confirma o estado do seu posto na virada.

---

## 10. Métricas de sucesso

Definidas **agora**, porque determinam o que o sistema precisa registrar.

| Métrica | Origem |
|---|---|
| Passaportes completos com quatro selos | Passaporte do Visitante |
| Fluxo de visitantes por espaço e por hora | Check-in nos quatro espaços |
| Itens e quilos desviados do descarte | EcoTracker na triagem e no escambo |
| Obras da galeria com ficha acessada | Catálogo da Galeria |
| Respostas e nota média de satisfação | Pesquisa na saída |
| Tempo médio de check-in e minutos em modo degradado | Registro de F5 |
| Interrupções técnicas na programação do palco | Registro de incidentes — **meta: zero** |

---

## 11. Matriz de riscos

Sem o sistema financeiro, nenhum risco remanescente é crítico no sentido de impedir a feira. Os altos impedem o TDS de entregar o que prometeu.

### `A-01` · Alto · Conteúdo atrasa e trava a Plataforma
F1 não publica hotsite, catálogo ou programação sem o material de F2. É a dependência mais provável de estourar, porque depende de terceiros: artistas, expositores, Grêmio, Agropecuária.

**Mitigação:** F2 entrega conteúdo em lotes parciais desde `S-8`, nunca de uma vez. F1 constrói contra dados de exemplo desde o início.

### `A-02` · Alto · Energia e rede no local
Via asfaltada interditada, ambiente externo, sem infraestrutura fixa. Sobrevive a qualquer corte de escopo.

**Mitigação:** todo posto opera offline por padrão, com sincronização oportunista. Autonomia por powerbank em 100% dos dispositivos. Levantamento em `S-10` e dois testes no local, em `S-6` e `S-3`.

### `A-03` · Alto · Capacidade de revisão, não de trabalho
Dois ou três avançados para 20+ alunos. Se a equipe de código crescer além de seis pessoas, a velocidade cai em vez de subir.

**Mitigação:** teto rígido de seis em F1, pareamento fixo, revisão obrigatória. O excedente vai para frentes que escalam com gente.

### `A-04` · Alto · Evasão silenciosa
Em turma grande, aluno sem tarefa nomeada some em duas semanas e reaparece no dia do evento sem saber o que fazer — e conta como equipe no papel.

**Mitigação:** nome de aluno escrito em tarefa no quadro desde `S-9`, limite de uma tarefa por vez, presença visível na demo de sexta. Líder reporta ausência no um-a-um.

### `M-05` · Médio · Passaporte duplicado
O projeto geral já tem o Passaporte do Leitor físico com selos. Duas mecânicas paralelas confundem o público na entrada.

**Resolvido por desenho:** um só cartão. Carimbo é o primário e nunca falha; o QR impresso no mesmo cartão espelha o registro digital.

### `M-06` · Médio · Autoridade não formalizada
Sem mandato escrito, o gestor responde pelo resultado mas precisa de autorização para cada decisão que o produz.

**Mitigação:** documento de uma página assinado na `S-10`, antes de qualquer trabalho começar.

### `B-07` · Baixo · Dados pessoais
Reduzido pela retirada do cadastro de visitantes, mas não zerado: fotos do evento e fichas de artistas envolvem imagem e nome de menores.

**Mitigação:** autorização de uso de imagem coletada pela escola antes do evento; passaporte apenas com código anônimo; descarte dos dados 30 dias após o relatório.

---

## 12. Próximos sete dias

Nada neste plano começa antes destes sete itens. Todos são do gestor — nenhum é delegável nesta primeira semana.

1. **Escrever e assinar o mandato.** Uma página com a coordenação: o gestor decide escopo e realoca pessoas dentro do TDS. Levar o organograma das cinco frentes junto.
2. **Resolver a contradição dos QR.** Confirmar com quem marcou o checklist se existe sistema de QR testado ou não. Todo o cronograma de F2 depende dessa resposta.
3. **Nomear os cinco líderes e conversar com cada um em separado.** Dizer o que espera, o que ele decide sozinho e o que traz para o gestor. Avançados vão para F1, F3 e F5.
4. **Ir ao local com o líder de F3.** Fotografar tomadas, medir distâncias, testar sinal de celular em cada zona. Uma hora presencial elimina semanas de suposição.
5. **Levantar o inventário real.** Quantos computadores, celulares, tablets, caixas de som, microfones e cabos a equipe tem acesso de fato — não em teoria.
6. **Apresentar o corte de escopo à direção.** Explicar que o sistema financeiro sai e o que entra no lugar, com o argumento de risco. Ir com o plano pronto, não com a dúvida.
7. **Montar o quadro e colocar o nome dos 20+ alunos nele.** Antes do kickoff de `S-9`, cada aluno já deve conseguir ver a própria tarefa.

---

## Como usar este repositório

```
README.md                    Este plano (documento principal)
PARECER.md                   Análise crítica dos documentos originais
CRONOGRAMA.md                Cronograma isolado, para imprimir e afixar
frentes/                     Um arquivo por frente — cada líder mantém o seu
docs/index.html              Plano navegável (publicável via GitHub Pages)
docs/parecer.html            Parecer navegável
scripts/bootstrap-github.sh  Cria milestones, labels e issues a partir do plano
.github/ISSUE_TEMPLATE/      Modelos de entregável e de incidente
```

**Sugestão de uso com a turma:** cada líder de frente mantém o próprio arquivo em `frentes/` via pull request. Além de manter o plano vivo, é a forma mais barata de ensinar Git e revisão de código a uma turma de TDS usando material que eles precisam ler de qualquer jeito.

Para publicar o plano navegável: **Settings → Pages → Source: Deploy from a branch → `main` / `/docs`**.

---

*Plano elaborado sobre o projeto geral do Mercado João Ferry 2026 e a proposta TechFerry, com o sistema financeiro retirado do escopo do TDS por decisão do gestor. Semanas em contagem regressiva sobre uma janela de dez semanas; dimensionamentos de frente são estimativas a ajustar conforme o efetivo confirmado da turma.*
