# F1 · Plataforma

**Tamanho:** 5–6 alunos (teto rígido de 6) · **Líder:** aluno mais experiente da turma · **Risco:** Alto

Única frente que escreve código de produto. Trabalha em **pares fixos** — um avançado com um ou dois iniciantes — com revisão obrigatória antes de qualquer entrega entrar no ar.

> ⚠️ **Teto de seis pessoas é regra, não sugestão.** Acrescentar iniciantes a esta frente reduz a velocidade dela: cada linha escrita por um iniciante consome tempo de revisão de um avançado, e revisão é o recurso escasso. Excedente vai para F2, F3 ou F4.

## Entregáveis

| # | Entregável | Critério de aceite | Prazo |
|---|---|---|---|
| 1 | Hotsite do evento | No ar com conteúdo real, legível no celular, sem dependência da rede local | `S-6` |
| 2 | Passaporte do Visitante | Check-in < 5s; offline com fila local; degrada para carimbo sem perder registro | `S-6` |
| 3 | Painel ao Vivo | Atualiza a cada 60s; legível a 3 metros; não trava se um posto cair | `S-6` |
| 4 | Catálogo da Galeria | 100% das obras com ficha publicada e QR impresso | `S-5` |
| 5 | EcoTracker | Operável pelo aluno da triagem em < 20s; total no Painel ao Vivo | `S-5` |
| 6 | Pesquisa de satisfação | Máximo 6 perguntas; resultado exportável | `S-5` |

## Princípios de construção

- **Offline por padrão.** Todo posto opera sem rede e sincroniza quando puder. A rede é otimização, nunca requisito.
- **Dados de exemplo desde o primeiro dia.** Nunca ficar parado esperando conteúdo de F2.
- **Degradação sem perda.** Se o digital cair, o carimbo assume e o registro é reconciliado depois.
- **Nenhum dado pessoal.** Apenas código impresso anônimo. Sem nome, telefone, CPF ou foto.
- **Revisão obrigatória.** Nada entra no ar sem revisão de outro par.

## Fora de escopo

Carteira digital, saldo, transferência, câmbio, painel de auditoria financeira, cadastro nominal de visitante, aplicativo instalável pelo público.

## Dependências

- **F2** entrega o conteúdo que o produto exibe. Bloqueio mais provável do projeto — ver risco `A-01`.
- **F3** entrega rede e dispositivos para os testes de `S-6` e `S-3`.
- **F5** aprova ou reprova cada entregável nos gates. F1 não valida a própria entrega.

## Gates

| Gate | Critério |
|---|---|
| `S-6` | Hotsite, check-in e painel ponta a ponta, fora da máquina de quem programou |
| `S-4` | **Feature freeze.** Só correção de defeito — nada novo entra |
| `S-2` | Go/no-go individual por entregável |
