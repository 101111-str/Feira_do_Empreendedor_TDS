# F2 · Conteúdo & Identidade Digital

**Tamanho:** 5–6 alunos · **Líder:** perfil de comunicação e organização (não precisa ser técnico) · **Risco:** Alto

Levanta e escreve tudo que o produto exibe, e produz todo o material físico impresso. É a frente que faz a ponte com Grêmio, Agropecuária, Administração e os alunos expositores.

> ⚠️ **Esta frente é o caminho crítico real do projeto.** F1 não publica nada sem o material de F2, e o material de F2 depende de terceiros — artistas, expositores, coordenações. É a dependência mais provável de estourar.

## Entregáveis

| # | Entregável | Critério de aceite | Prazo |
|---|---|---|---|
| 1 | Inventário de conteúdo | Lista completa de obras, espaços, expositores e itens da programação | `S-8` |
| 2 | Fichas das obras da galeria | Artista, título, técnica e preço, revisados | `S-5` |
| 3 | Programação do Palco Cultural | Alinhada com Grêmio, horário a horário | `S-5` |
| 4 | Textos do hotsite e mapa dos espaços | Revisados e aprovados | `S-6` |
| 5 | Material de divulgação e redes | No ar | `S-5` |
| 6 | Produção de QR e sinalização | Impressos, conferidos, plastificados, testados sob sol | `S-2` |

## Regra de entrega

**Conteúdo entregue em lotes parciais desde `S-8`, nunca de uma vez.** Um lote incompleto que chega cedo vale mais para F1 do que um lote completo que chega em `S-4`.

## Produção física

Passaportes, QR das obras, QR dos quatro espaços (Banco, Arte, Escambo, Verde), QR da pesquisa de saída, sinalização de percurso. Plastificação obrigatória — o evento é ao ar livre.

**Teste obrigatório:** imprimir uma amostra e escanear sob sol direto antes da produção em volume.

## Dependências

- **Grêmio** — programação cultural e acolhimento
- **Agropecuária** — curadoria da Feira Verde e oficinas
- **Administração** — dados do Banco da Feira e da pesquisa de satisfação
- **Alunos expositores e artistas** — fichas das obras
