# F3 · Infra de Campo

**Tamanho:** 4–5 alunos · **Líder:** segundo aluno mais experiente · **Risco:** Alto

Rede, energia, cabeamento, dispositivos, powerbanks, etiquetagem, montagem e desmontagem. Conduz as visitas de levantamento ao local e os testes de rede.

> **A frente que todo evento escolar esquece e a que mais derruba operação.** Eventos com tecnologia não falham por código ruim — falham por bateria, tomada e Wi-Fi.

## Entregáveis

| # | Entregável | Critério de aceite | Prazo |
|---|---|---|---|
| 1 | Levantamento do local | Fotos de tomadas, distâncias medidas, sinal de celular testado por zona | `S-10` |
| 2 | Inventário de dispositivos | Quantos computadores, celulares, tablets, caixas de som, microfones e cabos existem **de fato** | `S-10` |
| 3 | Mapa de energia e cabeamento | Validado presencialmente no local | `S-8` |
| 4 | Lista de aquisição e empréstimo | Fechada e aprovada | `S-7` |
| 5 | Rede local testada | Teste no local em `S-6` e no ensaio de `S-3`, com queda proposital | `S-3` |
| 6 | Dispositivos preparados | Carregados, etiquetados e separados por posto | `S-1` |

## Premissa de projeto

**A rede vai funcionar mal.** Todo posto opera offline por padrão e sincroniza quando puder. Autonomia por powerbank em 100% dos dispositivos, dimensionada para a duração total do evento mais duas horas.

## Kit de contingência

Montado e conferido item a item em `S-1`:

- [ ] Powerbanks carregados (um por posto + 2 reservas)
- [ ] Roteador reserva
- [ ] Extensões e filtros de linha
- [ ] Cabos de carga de cada tipo em uso
- [ ] Fita crepe e fita isolante
- [ ] Etiquetas e canetas
- [ ] Lista impressa de contatos da equipe

## Dependências

- **Direção da escola** — autorização de acesso ao local e uso de energia
- **F4** — posicionamento de som define pontos de energia
- **F1** — número e tipo de postos define cobertura necessária
