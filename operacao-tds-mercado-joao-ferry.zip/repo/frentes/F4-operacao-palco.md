# F4 · Operação & Palco

**Tamanho:** 4–5 alunos · **Líder:** perfil de coordenação, não técnico · **Risco:** Médio

Som, microfone e trilha sonora; apoio ao mestre de cerimônia e ao cronograma ininterrupto do Palco Cultural e do Desfile da Sustentabilidade. Monta e executa a escala dos postos de check-in por turno.

## Entregáveis

| # | Entregável | Critério de aceite | Prazo |
|---|---|---|---|
| 1 | Cronograma do Palco Cultural | Alinhado com o Grêmio, horário a horário | `S-8` |
| 2 | Plano de sonorização | Equipamento, posicionamento e operador definidos por momento | `S-5` |
| 3 | Trilha da Cafeteria Literária | Selecionada e testada no equipamento real | `S-3` |
| 4 | Escala do dia do evento | Todo posto com titular e substituto nomeados | `S-2` |
| 5 | Operação no dia | Cronograma cumprido sem interrupção técnica | `S-0` |

## Cobertura de som

- Palco Cultural: mestre de cerimônia, batalhas de leitura, contação de histórias, entrevistas ao vivo
- Desfile da Sustentabilidade
- Cafeteria Literária: trilha sonora ambiente contínua
- Anúncios gerais da organização

## Regra de escala

**Todo posto tem substituto escalado.** Aluno que precisa sair — comer, banheiro, apresentação própria — não deixa um espaço do passaporte ou a mesa de som sem operador.

Escala publicada em `S-2` e conferida no briefing de `S-1`: cada aluno sabe seu posto, seu turno e seu substituto.

## Dependências

- **Grêmio** — programação cultural e mestre de cerimônia
- **F3** — energia e posicionamento dos pontos de som
- **F1** — postos de check-in a serem cobertos pela escala
