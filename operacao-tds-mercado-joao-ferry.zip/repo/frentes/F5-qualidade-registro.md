# F5 · Qualidade, Registro & Plantão

**Tamanho:** 3–4 alunos · **Líder:** terceiro aluno experiente · **Reporta:** direto ao gestor geral

Escreve e executa os roteiros de teste, conduz os dois ensaios gerais, registra defeitos e cronometra os tempos de aceite. Durante o evento, faz o plantão técnico e o registro audiovisual. Depois, conduz o pós-morte.

> **Por que F5 não fica dentro de F1:** quem escreve o código não pode decidir se o código está pronto. Com prazo apertado, a pressão para aprovar a própria entrega é grande demais. F5 reportando direto ao gestor é a **única fonte independente** sobre o estado real do projeto — e a única confiável na semana do go/no-go.

## Entregáveis

| # | Entregável | Critério de aceite | Prazo |
|---|---|---|---|
| 1 | Roteiros de teste | Escritos **antes** de existir o que testar | `S-7` |
| 2 | Ensaio geral 1 | Conduzido no local, com defeitos e tempos registrados | `S-3` |
| 3 | Parecer de go/no-go | Um parecer por entregável, entregue ao gestor | `S-2` |
| 4 | Ensaio geral 2 | Jornada completa: entrada → Banco → estandes → escambo → galeria → saída | `S-1` |
| 5 | Plantão técnico | Titular e reserva por turno, conforme escala | `S-0` |
| 6 | Registro audiovisual | Material editado entregue | `S-0` + 7 dias |
| 7 | Pós-morte | Relatório consolidado a partir do registro de incidentes | `S-0` + 7 dias |

## Ensaio geral 1 — `S-3`

Executado **no local**, com infraestrutura real:

- [ ] Rede, energia e dispositivos montados no espaço do evento
- [ ] Três postos operando simultaneamente
- [ ] 50 check-ins cronometrados — registrar tempo médio e pior caso
- [ ] **Teste de degradação:** derrubar a rede e medir o tempo de retorno ao carimbo
- [ ] Defeitos registrados com reprodução, gravidade e responsável

## Registro de incidentes

**Em papel**, preenchido durante a feira. Cada linha: horário, posto, o que aconteceu, o que foi feito, quanto tempo durou.

Vira o pós-morte e é o melhor material de avaliação que o projeto produz.

## Autoridade

O líder de F5, junto com o gestor geral, é uma das **duas únicas pessoas autorizadas a declarar degradação** durante o evento.

## Dependências

Nenhuma frente bloqueia F5. F5 bloqueia a entrada de F1 em produção.
