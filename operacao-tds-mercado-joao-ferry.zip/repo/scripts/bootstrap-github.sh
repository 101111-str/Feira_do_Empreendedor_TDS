#!/usr/bin/env bash
# Cria milestones, labels e issues deste plano no repositório atual.
# Requer: gh CLI autenticado (gh auth login) e o repositório já criado no GitHub.
# Uso: bash scripts/bootstrap-github.sh

set -euo pipefail

command -v gh >/dev/null || { echo "gh CLI não encontrado. Instale: https://cli.github.com"; exit 1; }
gh auth status >/dev/null 2>&1 || { echo "gh não autenticado. Rode: gh auth login"; exit 1; }

echo "==> Criando labels das frentes"
gh label create "F1-plataforma"   --color 0E8A6A --description "Produto digital" --force
gh label create "F2-conteudo"     --color B8860B --description "Conteúdo e identidade digital" --force
gh label create "F3-infra-campo"  --color 8B4513 --description "Rede, energia, dispositivos" --force
gh label create "F4-operacao"     --color 4A5D8A --description "Som, palco, escala" --force
gh label create "F5-qualidade"    --color 6B2D5C --description "Testes, ensaios, plantão" --force
gh label create "entregavel"      --color 1D76DB --description "Item de escopo com critério de aceite" --force
gh label create "incidente"       --color D73A4A --description "Falha em ensaio ou no evento" --force
gh label create "bloqueado"       --color B60205 --description "Parado aguardando dependência" --force

echo "==> Criando milestones (gates)"
create_milestone() {
  gh api "repos/{owner}/{repo}/milestones" -f title="$1" -f description="$2" >/dev/null 2>&1 \
    && echo "    + $1" || echo "    = $1 (já existe)"
}
create_milestone "S-6 · Gate 1 — Integração"     "Hotsite, check-in e painel ponta a ponta fora da máquina de quem programou"
create_milestone "S-4 · Gate 2 — Feature freeze" "Seis entregáveis digitais existem e funcionam. Só correção a partir daqui"
create_milestone "S-2 · Gate 3 — Go/No-go"       "Parecer individual por entregável após o ensaio geral 1"
create_milestone "S-0 · Evento"                  "Montagem, operação e desmontagem"

echo "==> Criando issues dos entregáveis"
issue() { # frente, milestone, titulo, corpo
  gh issue create --label "$1" --label entregavel --milestone "$2" --title "$3" --body "$4" >/dev/null \
    && echo "    + $3"
}

M1="S-6 · Gate 1 — Integração"
M2="S-4 · Gate 2 — Feature freeze"
M3="S-2 · Gate 3 — Go/No-go"
M4="S-0 · Evento"

issue F1-plataforma "$M1" "[F1] Hotsite do evento" \
"Página pública com programação, mapa do zoneamento, espaços, expositores e como participar.

**Critério de aceite:** no ar com conteúdo real, legível no celular, sem dependência da rede local.
**Depende de:** F2 — textos e mapa."

issue F1-plataforma "$M1" "[F1] Passaporte do Visitante" \
"Espelho digital do passaporte físico. O aluno operador escaneia o QR do cartão em cada um dos quatro espaços. O visitante não instala nada.

**Critério de aceite:** check-in em menos de 5s; funciona offline com fila local; degrada para carimbo sem perder registro."

issue F1-plataforma "$M1" "[F1] Painel ao Vivo" \
"Tela no evento e página pública: visitantes por espaço, fluxo por hora, próximo item do Palco Cultural, contador do EcoTracker.

**Critério de aceite:** atualiza a cada 60s; legível a 3 metros; não trava se um posto cair."

issue F1-plataforma "$M2" "[F1] Catálogo da Galeria" \
"QR por obra levando à ficha do artista, título, técnica e preço.

**Critério de aceite:** 100% das obras com ficha publicada e QR impresso.
**Depende de:** F2 — fichas das obras."

issue F1-plataforma "$M2" "[F1] EcoTracker" \
"Registro de itens e quilos desviados do descarte na triagem e no escambo.

**Critério de aceite:** operável pelo aluno da triagem em menos de 20s; total exibido no Painel ao Vivo."

issue F1-plataforma "$M2" "[F1] Pesquisa de satisfação" \
"QR na saída, questionário curto. Instrumento do TDS, leitura pela Administração.

**Critério de aceite:** máximo 6 perguntas; resultado exportável."

issue F2-conteudo "$M1" "[F2] Inventário de conteúdo" \
"Lista completa de obras, espaços, expositores e itens da programação.

**Critério de aceite:** inventário fechado e compartilhado com F1."

issue F2-conteudo "$M2" "[F2] Fichas das obras da galeria" \
"Artista, título, técnica e preço, revisados.

**Regra:** entregar em lotes parciais, nunca de uma vez."

issue F2-conteudo "$M1" "[F2] Programação do Palco Cultural" \
"Alinhada com o Grêmio, horário a horário.
**Depende de:** Grêmio Estudantil."

issue F2-conteudo "$M3" "[F2] Produção de QR e sinalização" \
"Passaportes, obras, quatro espaços, pesquisa e percurso.

**Critério de aceite:** impressos, conferidos, plastificados. Amostra testada sob sol direto antes da produção em volume."

issue F3-infra-campo "$M1" "[F3] Levantamento do local" \
"Fotos de tomadas, distâncias medidas, sinal de celular testado por zona.

**Prazo:** S-10. Primeira tarefa do projeto."

issue F3-infra-campo "$M1" "[F3] Inventário de dispositivos" \
"Quantos computadores, celulares, tablets, caixas de som, microfones e cabos a equipe tem acesso **de fato**, não em teoria."

issue F3-infra-campo "$M1" "[F3] Mapa de energia e cabeamento" \
"**Critério de aceite:** validado presencialmente no local em S-8."

issue F3-infra-campo "$M3" "[F3] Rede local testada" \
"**Critério de aceite:** testada no local em S-6 e no ensaio de S-3, incluindo teste de queda proposital."

issue F3-infra-campo "$M4" "[F3] Kit de contingência" \
"Powerbanks, roteador reserva, extensões, cabos, fita, etiquetas, canetas, lista impressa de contatos.

**Critério de aceite:** montado e conferido item a item em S-1."

issue F4-operacao "$M1" "[F4] Cronograma do Palco Cultural" \
"Alinhado com o Grêmio, horário a horário.
**Critério de aceite:** cronograma ininterrupto, sem lacuna sem responsável."

issue F4-operacao "$M2" "[F4] Plano de sonorização" \
"Equipamento, posicionamento e operador definidos por momento: palco, desfile, cafeteria, anúncios."

issue F4-operacao "$M3" "[F4] Escala do dia do evento" \
"**Critério de aceite:** todo posto com titular e substituto nomeados. Publicada em S-2 e conferida no briefing de S-1."

issue F5-qualidade "$M1" "[F5] Roteiros de teste" \
"Escritos **antes** de existir o que testar.
**Prazo:** S-7."

issue F5-qualidade "$M3" "[F5] Ensaio geral 1 no local" \
"Rede, energia e dispositivos reais. Três postos, 50 check-ins cronometrados, teste de degradação.

**Critério de aceite:** defeitos registrados com reprodução, gravidade e responsável."

issue F5-qualidade "$M3" "[F5] Parecer de go/no-go" \
"Um parecer por entregável, entregue ao gestor geral. F5 reporta direto ao gestor, não a F1."

issue F5-qualidade "$M4" "[F5] Ensaio geral 2 — jornada completa" \
"Entrada → Banco → estandes → escambo → galeria → saída."

echo
echo "Pronto. Confira em: gh issue list"
